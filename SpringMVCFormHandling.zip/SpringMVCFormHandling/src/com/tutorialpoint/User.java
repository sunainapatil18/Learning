package com.tutorialpoint;

public class User {
	
   private Integer Amount;
   /*private String password;
   private String address;
   private boolean receivePaper;
   private String [] favoriteFrameworks;   
   private String gender;
   private String favoriteNumber;*/
   private String country;
   
   private String countryTo;
   
   public String getCountryTo() {
	return countryTo;
}
public void setCountryTo(String countryTo) {
	this.countryTo = countryTo;
}
public Integer getAmount() {
      return Amount;
   }
   public void setAmount(Integer Amount) {
      this.Amount = Amount;
   }

   /*public String getPassword() {
      return password;
   }
   public void setPassword(String password) {
      this.password = password;
   }
   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }
   public boolean isReceivePaper() {
      return receivePaper;
   }
   public void setReceivePaper(boolean receivePaper) {
      this.receivePaper = receivePaper;
   }
   public String[] getFavoriteFrameworks() {
      return favoriteFrameworks;
   }
   public void setFavoriteFrameworks(String[] favoriteFrameworks) {
      this.favoriteFrameworks = favoriteFrameworks;
   }
   public String getGender() {
      return gender;
   }
   public void setGender(String gender) {
      this.gender = gender;
   }
   public String getFavoriteNumber() {
      return favoriteNumber;
   }
   public void setFavoriteNumber(String favoriteNumber) {
      this.favoriteNumber = favoriteNumber;
   }*/
   public String getCountry() {
      return country;
   }
   public void setCountry(String country) {
      this.country = country;
   }
}