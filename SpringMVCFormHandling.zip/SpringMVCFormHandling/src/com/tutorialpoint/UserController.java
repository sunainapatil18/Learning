package com.tutorialpoint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;

@Controller
public class UserController {

   @RequestMapping(value = "/user", method = RequestMethod.GET)
   public ModelAndView user() {
      User user = new User();	  
	  
	  ModelAndView modelAndView = new ModelAndView("user", "command", user);
	  return modelAndView;
   }

   @RequestMapping(value = "/addUser", method = RequestMethod.POST)
   public String addUser(@ModelAttribute("SpringWeb")User user, 
      ModelMap model) {
      model.addAttribute("Amount", user.getAmount());
     /* model.addAttribute("password", user.getPassword());
      model.addAttribute("address", user.getAddress());
      model.addAttribute("receivePaper", user.isReceivePaper());
	  model.addAttribute("favoriteFrameworks", user.getFavoriteFrameworks());
      model.addAttribute("gender", user.getGender());
      model.addAttribute("favoriteNumber", user.getFavoriteNumber());*/
      int result=0;
      
      String a1=user.getCountry();
      String a2=user.getCountryTo();
      if(a1.equals(a2)){
    	  
      }
     // model.addAttribute("country", user.getCountry());     
      if(a1.equals("IN")){
    	  switch(a2){  
          case "CH":  
              result=2*user.getAmount(); 
              break;  
          case "SG":  
        	  result=3*user.getAmount(); 
              break;  
          case "MY":  
        	  result=4*user.getAmount(); 
        	  break;
          }  
      }else if(a1.equals("CH")){
    	  switch(a2){  
          case "IN":  
              result=2*user.getAmount(); 
              break;  
          case "SG":  
        	  result=8*user.getAmount(); 
              break;  
          case "MY":  
        	  result=6*user.getAmount(); 
        	  break;
          }  
      } else if(a1.equals("SG")){
    	  switch(a2){  
          case "IN":  
              result=3*user.getAmount(); 
              break;  
          case "CH":  
        	  result=8*user.getAmount(); 
              break;  
          case "MY":  
        	  result=7*user.getAmount(); 
        	  break;
          }  
      }else if(a1.equals("MY")){
    	  switch(a2){  
          case "IN":  
              result=4*user.getAmount(); 
              break;  
          case "CH":  
        	  result=6*user.getAmount(); 
              break;  
          case "SG":  
        	  result=7*user.getAmount(); 
        	  break;
          }  
      }
    	  
      model.addAttribute("country",result );
      return "users";
   }
   
   /*@ModelAttribute("webFrameworkList")
   public List<String> getWebFrameworkList() {
      List<String> webFrameworkList = new ArrayList<String>();
      webFrameworkList.add("Spring MVC");
      webFrameworkList.add("Struts 1");
      webFrameworkList.add("Struts 2");
      webFrameworkList.add("Apache Wicket");
      return webFrameworkList;
   }
   
   @ModelAttribute("numbersList")
   public List<String> getNumbersList() {
      List<String> numbersList = new ArrayList<String>();
      numbersList.add("1");
      numbersList.add("2");
      numbersList.add("3");
      numbersList.add("4");
      return numbersList;
   }*/

   @ModelAttribute("countryList")
   public Map<String, String> getCountryList() {
      Map<String, String> countryList = new HashMap<String, String>();
      countryList.put("US", "United States");
      countryList.put("CH", "China");
      countryList.put("SG", "Singapore");
      countryList.put("MY", "Malaysia");
      return countryList;
   }
   
   @ModelAttribute("countryListTo")
   public Map<String, String> getCountry() {
      Map<String, String> countryListTo = new HashMap<String, String>();
      countryListTo.put("US", "United States");
      countryListTo.put("CH", "China");
      countryListTo.put("SG", "Singapore");
      countryListTo.put("MY", "Malaysia");
      return countryListTo;
   }
   
   
   
   
}